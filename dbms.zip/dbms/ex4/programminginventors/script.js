function start(){
    var lang = document.getElementById("language").value;

    //let langreg = new RegExp("^"+lang+"\.(png|jpg)$")
    //console.log(langreg);
    let langreg = new RegExp(lang+"\\d*\.(gif|jpg|jpeg|tiff|png)")
    console.log(langreg);
    let creatorlist = ["python.jpg", "cpp.jpg", "java.jpg"]
    let creatorstr = creatorlist.join(" ")
    console.log(creatorstr);
    const found = creatorstr.match(langreg);
    console.log(found);
    var img = document.createElement("img");
    img.src = "images/"+found[0];
    var src = document.getElementById("x");
     
    src.appendChild(img);

}